import { createFileRoute, Link } from "@tanstack/react-router";
import { attemptsByKind } from "@/lib/assessment";
import { publishedSubjects, useContent } from "@/lib/content";
import { plural } from "@/lib/format";
import { bestByTopic, useSession } from "@/lib/session";

export const Route = createFileRoute("/studio/progress")({ component: ProgressPage });

function ProgressPage() {
  const attempts = useSession((s) => s.attempts);
  const selected = useSession((s) => s.selectedSubjects);
  const best = bestByTopic(attempts);
  const all = publishedSubjects(useContent((s) => s.subjects));
  const mine = (selected.length ? selected : []).map((id) => all.find((s) => s.id === id)).filter((s): s is NonNullable<typeof s> => Boolean(s));
  const { topic: topicAttempts, jamb, waec } = attemptsByKind(attempts);

  const cards = mine.map((subject) => {
    const rows = subject.topics.map((topic) => best.get(topic.id)).filter(Boolean);
    const attempted = subject.topics.filter((t) => best.has(t.id)).length;
    const avg = rows.length ? Math.round(rows.reduce((s, a) => s + (a!.score / Math.max(a!.total, 1)) * 100, 0) / rows.length) : null;
    return { subject, attempted, avg };
  });

  return (
    <div>
      <h1 className="font-display text-4xl">Progress</h1>
      <p className="mt-2 max-w-xl text-muted">
        {attempts.length === 0
          ? "No attempts yet. Open one of your subjects and sit a topic quiz."
          : `${plural(topicAttempts.length, "topic attempt")} · ${plural(jamb.length, "JAMB")} · ${plural(waec.length, "WAEC")}`}
      </p>

      <h2 className="mt-8 font-display text-2xl">Your subjects</h2>
      {cards.length === 0 ? (
        <p className="mt-3 text-sm text-muted">Choose your four subjects in Account.</p>
      ) : (
        <ul className="mt-3 grid gap-3 sm:grid-cols-2">
          {cards.map(({ subject, attempted, avg }) => (
            <li key={subject.id} className="rounded-2xl border border-line bg-surface p-4">
              <p className="font-display text-xl">{subject.name}</p>
              <p className="mt-1 text-sm text-muted">
                {attempted === 0 ? "Not started" : `${attempted} of ${subject.topics.length} topics · best average ${avg}%`}
              </p>
              <Link to="/studio/subject/$id" params={{ id: subject.id }} className="mt-3 inline-flex min-h-11 items-center text-sm font-semibold text-primary">Open subject</Link>
            </li>
          ))}
        </ul>
      )}

      <h2 className="mt-10 font-display text-2xl">Exam attempts</h2>
      {jamb.length + waec.length === 0 ? (
        <p className="mt-3 text-sm text-muted">No JAMB or WAEC attempts yet. Those stay separate from topic quizzes.</p>
      ) : (
        <ul className="mt-3 divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
          {[...jamb, ...waec].map((a) => (
            <li key={a.id}>
              <Link to="/studio/review/$attemptId" params={{ attemptId: a.id }} className="flex min-h-14 items-center justify-between px-4 py-3">
                <span>
                  <span className="block font-medium">{a.title}</span>
                  <span className="text-xs text-muted">{a.kind.toUpperCase()} · {new Date(a.at).toLocaleDateString("en-NG")}</span>
                </span>
                <span className="text-sm font-semibold">{a.score}/{a.total}</span>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
