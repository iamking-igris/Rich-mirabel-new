import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { publishedSubjects, useContent } from "@/lib/content";

export const Route = createFileRoute("/admin/cbt")({ component: CbtGenerator });

type Config = { id: string; title: string; subject: string; count: number; minutes: number; status: "Draft" | "Ready"; source: string };

function CbtGenerator() {
  const subjects = publishedSubjects(useContent((s) => s.subjects));
  const [configs, setConfigs] = useState<Config[]>([
    { id: "c1", title: "Physics mixed demo", subject: "Physics", count: 10, minutes: 15, status: "Ready", source: "Topic quizzes + demo past questions" },
  ]);
  const [step, setStep] = useState(0);
  const [title, setTitle] = useState("New practice CBT");
  const [subject, setSubject] = useState(subjects[0]?.name ?? "Physics");
  const [count, setCount] = useState(10);
  const [minutes, setMinutes] = useState(15);
  const [source, setSource] = useState("Verified past questions + topic quizzes");
  const pool = 12;
  const short = count > pool;

  function save(status: "Draft" | "Ready") {
    setConfigs((current) => [{ id: `c_${Date.now()}`, title, subject, count, minutes, status, source }, ...current]);
    setStep(0);
  }

  return (
    <div>
      <h1 className="font-display text-4xl">CBT Generator</h1>
      <p className="mt-2 text-sm text-muted">Builds a practice test from eligible questions. Not the same as Past Questions. Demo only.</p>
      <div className="mt-4 flex flex-wrap gap-2 text-sm">
        {["Details", "Sources", "Settings", "Review", "Save"].map((label, i) => (
          <button key={label} type="button" onClick={() => setStep(i)} className={`min-h-10 rounded-full px-3 ${step === i ? "bg-ink text-primary-fg" : "border border-line"}`}>{label}</button>
        ))}
      </div>
      <section className="mt-4 rounded-2xl border border-line bg-surface p-5">
        {step === 0 && (
          <>
            <label className="text-sm">Title</label>
            <input value={title} onChange={(e) => setTitle(e.target.value)} className="mt-1 w-full rounded-xl border border-line bg-paper px-3 py-2" />
            <label className="mt-3 block text-sm">Subject</label>
            <select value={subject} onChange={(e) => setSubject(e.target.value)} className="mt-1 w-full rounded-xl border border-line bg-paper px-3 py-2">
              {subjects.map((s) => <option key={s.id}>{s.name}</option>)}
            </select>
          </>
        )}
        {step === 1 && (
          <label className="text-sm">Sources
            <select value={source} onChange={(e) => setSource(e.target.value)} className="mt-1 block w-full rounded-xl border border-line bg-paper px-3 py-2">
              <option>Verified past questions</option>
              <option>Teacher topic quizzes</option>
              <option>Approved AI practice</option>
              <option>Verified past questions + topic quizzes</option>
            </select>
            <span className="mt-2 block text-xs text-muted">Generated items stay labelled. They are not official past questions.</span>
          </label>
        )}
        {step === 2 && (
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="text-sm">Questions
              <input type="number" min={1} value={count} onChange={(e) => setCount(Number(e.target.value))} className="mt-1 block w-full rounded-xl border border-line bg-paper px-3 py-2" />
            </label>
            <label className="text-sm">Minutes
              <input type="number" min={1} value={minutes} onChange={(e) => setMinutes(Number(e.target.value))} className="mt-1 block w-full rounded-xl border border-line bg-paper px-3 py-2" />
            </label>
          </div>
        )}
        {step === 3 && (
          <p className="text-sm">
            {short
              ? `Insufficient eligible questions. Pool has ${pool}, you asked for ${count}. Lower the count or add questions.`
              : `Ready for preview. ${count} questions from ${source}. Unseen questions are preferred when a real student history exists.`}
          </p>
        )}
        {step === 4 && (
          <div className="flex gap-2">
            <button type="button" onClick={() => save("Draft")} className="min-h-11 rounded-full border border-line px-4 text-sm font-semibold">Save draft</button>
            <button type="button" disabled={short} onClick={() => save("Ready")} className="min-h-11 rounded-full bg-primary px-4 text-sm font-semibold text-primary-fg disabled:opacity-40">Mark ready</button>
          </div>
        )}
      </section>
      <h2 className="mt-8 font-display text-2xl">Configurations</h2>
      <ul className="mt-3 divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
        {configs.map((c) => (
          <li key={c.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 text-sm">
            <span>{c.title} · {c.subject} · {c.count} questions · {c.status}</span>
            <Link to="/studio/cbt" className="font-semibold text-primary">Preview student CBT</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
