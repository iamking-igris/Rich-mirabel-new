import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { demoUsers, type DemoUser } from "@/lib/admin-ops";

export const Route = createFileRoute("/admin/students")({ component: Students });

function Students() {
  const [users, setUsers] = useState<DemoUser[]>(demoUsers);
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<string | null>(null);
  const shown = useMemo(() => users.filter((u) => u.name.toLowerCase().includes(q.toLowerCase()) || u.email.includes(q.toLowerCase())), [users, q]);
  const selected = users.find((u) => u.id === open);

  return (
    <div>
      <h1 className="font-display text-4xl">Students</h1>
      <p className="mt-2 text-sm text-muted">Demo accounts. Suspending one changes this screen only.</p>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name or email" className="mt-4 min-h-11 w-full rounded-xl border border-line bg-surface px-3" />
      <ul className="mt-3 divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
        {shown.map((u) => (
          <li key={u.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 text-sm">
            <span>{u.name} · {u.access} · {u.status}</span>
            <span className="flex gap-2">
              <button type="button" onClick={() => setOpen(u.id)} className="min-h-9 rounded-full border border-line px-3">View</button>
              <button type="button" onClick={() => setUsers((rows) => rows.map((row) => row.id === u.id ? { ...row, status: row.status === "Suspended" ? "Active" : "Suspended" } : row))} className="min-h-9 rounded-full border border-line px-3">
                {u.status === "Suspended" ? "Restore" : "Suspend"}
              </button>
            </span>
          </li>
        ))}
        {shown.length === 0 && <li className="px-4 py-6 text-sm text-muted">No matching students.</li>}
      </ul>
      {selected && (
        <div className="fixed inset-0 z-30 flex items-end justify-center bg-ink/40 p-4 sm:items-center" role="dialog">
          <div className="w-full max-w-md rounded-3xl bg-surface p-6">
            <h2 className="font-display text-2xl">{selected.name}</h2>
            <dl className="mt-3 space-y-2 text-sm">
              <div className="flex justify-between"><dt className="text-muted">Email</dt><dd>{selected.email}</dd></div>
              <div className="flex justify-between"><dt className="text-muted">Status</dt><dd>{selected.status}</dd></div>
              <div className="flex justify-between"><dt className="text-muted">Access</dt><dd>{selected.access}</dd></div>
              <div className="flex justify-between"><dt className="text-muted">Subjects</dt><dd className="text-right">{selected.subjects.join(", ")}</dd></div>
              <div className="flex justify-between"><dt className="text-muted">Registered</dt><dd>{selected.registered}</dd></div>
            </dl>
            <button type="button" onClick={() => setOpen(null)} className="mt-5 min-h-11 w-full rounded-full bg-primary font-semibold text-primary-fg">Close</button>
          </div>
        </div>
      )}
    </div>
  );
}
