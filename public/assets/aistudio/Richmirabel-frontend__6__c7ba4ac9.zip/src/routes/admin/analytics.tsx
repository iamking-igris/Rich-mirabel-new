import { createFileRoute } from "@tanstack/react-router";
import { useContent } from "@/lib/content";
import { useSession } from "@/lib/session";

export const Route = createFileRoute("/admin/analytics")({ component: Analytics });

function Analytics() {
  const subjects = useContent((s) => s.subjects);
  const attempts = useSession((s) => s.attempts);
  const prepared = subjects.filter((s) => s.id === "physics" || s.topics.some((t) => t.status !== "draft" && t.notes.length > 0)).length;
  const topic = attempts.filter((a) => a.kind === "topic" || !a.kind);

  return (
    <div>
      <h1 className="font-display text-4xl">Analytics</h1>
      <p className="mt-2 text-sm text-muted">Figures from the content store and this browser’s attempts. No invented trends.</p>
      <h2 className="mt-6 font-display text-2xl">Content</h2>
      <div className="mt-3 grid grid-cols-3 gap-3">
        <Stat label="Subjects" value={String(subjects.length)} />
        <Stat label="Topics" value={String(subjects.flatMap((s) => s.topics).length)} />
        <Stat label="Prepared" value={String(prepared)} />
      </div>
      <h2 className="mt-8 font-display text-2xl">Learning</h2>
      {attempts.length === 0 ? (
        <p className="mt-2 text-sm text-muted">No attempts on this device yet. Sit a topic quiz as a student to populate this.</p>
      ) : (
        <ul className="mt-3 divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
          {topic.slice(0, 6).map((a) => (
            <li key={a.id} className="flex items-center justify-between px-4 py-3 text-sm">
              <span>{a.title}</span>
              <span>{a.score}/{a.total}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
function Stat({ label, value }: { label: string; value: string }) {
  return <div className="rounded-2xl border border-line bg-surface p-4"><p className="text-sm text-muted">{label}</p><p className="font-display text-3xl">{value}</p></div>;
}
