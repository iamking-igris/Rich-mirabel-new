import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";

export const Route = createFileRoute("/admin/past-questions")({ component: PastQuestions });

type Set = { id: string; title: string; subject: string; year: string; source: string; status: "Draft" | "Review" | "Published"; questions: number };

const seed: Set[] = [
  { id: "pq1", title: "Physics objective sample", subject: "Physics", year: "Demo", source: "Teacher booklet · DEMO", status: "Review", questions: 4 },
];

export function PastQuestions() {
  const [sets, setSets] = useState<Set[]>(seed);
  const [step, setStep] = useState<0 | 1 | 2 | 3 | 4 | 5>(0);
  const [subject, setSubject] = useState("Physics");
  const [year, setYear] = useState("Demo");
  const [qPages, setQPages] = useState(0);
  const [kPages, setKPages] = useState(0);

  function publish() {
    setSets((current) => [{ id: `pq_${Date.now()}`, title: `${subject} ${year}`, subject, year, source: "Uploaded pages · DEMO", status: "Published", questions: 4 }, ...current]);
    setStep(0);
  }

  return (
    <div>
      <h1 className="font-display text-4xl">Past Questions</h1>
      <p className="mt-2 text-sm text-muted">Independent of lesson topics. Demo importer — no real OCR.</p>
      <div className="mt-4 flex flex-wrap gap-2 text-sm">
        {["Set details", "Question pages", "Answer key", "Extract", "Review", "Publish"].map((label, i) => (
          <button key={label} type="button" onClick={() => setStep(i as typeof step)} className={`min-h-10 rounded-full px-3 ${step === i ? "bg-ink text-primary-fg" : "border border-line"}`}>{i + 1}. {label}</button>
        ))}
      </div>
      <section className="mt-4 rounded-2xl border border-line bg-surface p-5">
        {step === 0 && (
          <>
            <label className="text-sm">Subject</label>
            <input value={subject} onChange={(e) => setSubject(e.target.value)} className="mt-1 w-full rounded-xl border border-line bg-paper px-3 py-+2 py-2" />
            <label className="mt-3 block text-sm">Year label</label>
            <input value={year} onChange={(e) => setYear(e.target.value)} className="mt-1 w-full rounded-xl border border-line bg-paper px-3 py-2" />
            <p className="mt-2 text-xs text-muted">Use “Demo” unless you have a verified paper. Do not invent an official year.</p>
          </>
        )}
        {step === 1 && (
          <label className="flex min-h-28 cursor-pointer items-center justify-center rounded-2xl border border-dashed border-line">
            <input type="file" accept="image/*" multiple className="sr-only" onChange={(e) => setQPages(e.target.files?.length ?? 0)} />
            {qPages ? `${qPages} question page(s) selected` : "Upload question page photos"}
          </label>
        )}
        {step === 2 && (
          <label className="flex min-h-28 cursor-pointer items-center justify-center rounded-2xl border border-dashed border-line">
            <input type="file" accept="image/*" multiple className="sr-only" onChange={(e) => setKPages(e.target.files?.length ?? 0)} />
            {kPages ? `${kPages} answer-key page(s) selected` : "Upload answer key / explanation photos"}
          </label>
        )}
        {step === 3 && <p className="text-sm">Simulated match: question numbers are paired with the same numbers on the answer key. Missing keys stay flagged. No AI has read the files.</p>}
        {step === 4 && (
          <ul className="space-y-2 text-sm">
            <li className="rounded-xl border border-line p-3">Q1 · v = fλ · Answer B · Matched from key</li>
            <li className="rounded-xl border border-line p-3">Q2 · SI unit of force · Answer C · Matched from key</li>
            <li className="rounded-xl border border-line p-3">Q27 · Frequency · Answer missing · AI-suggested — unverified</li>
          </ul>
        )}
        {step === 5 && <button type="button" onClick={publish} className="min-h-11 rounded-full bg-primary px-5 text-sm font-semibold text-primary-fg">Approve and publish demo set</button>}
      </section>
      <h2 className="mt-8 font-display text-2xl">Library</h2>
      <ul className="mt-3 divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
        {sets.map((set) => (
          <li key={set.id} className="flex items-center justify-between px-4 py-3 text-sm">
            <span>{set.title} · {set.subject} · {set.year} · {set.status}</span>
            <span className="text-muted">{set.questions} questions</span>
          </li>
        ))}
      </ul>
      <p className="mt-3 text-xs text-muted"><Link to="/admin/cbt" className="text-primary">Use approved sets in CBT Generator</Link></p>
    </div>
  );
}
