import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { loadOps, saveOps } from "@/lib/admin-ops";

type Row = { id: string; number: string; prompt: string; options: string; answer: string; explain: string; status: "Extracted" | "Matched" | "Uncertain" | "Approved"; source: string; };

const seed: Row[] = [
  { id: "q1", number: "1", prompt: "v = fλ is the equation for", options: "A force · B wave speed · C power · D pressure", answer: "B", explain: "Wave speed equals frequency times wavelength.", status: "Matched", source: "Teacher key" },
  { id: "q2", number: "2", prompt: "SI unit of force is the", options: "A joule · B watt · C newton · D pascal", answer: "C", explain: "Newton.", status: "Matched", source: "Teacher key" },
  { id: "q3", number: "26", prompt: "A body from rest has u equal to", options: "A g · B 0 · C 1 · D infinity", answer: "B", explain: "Rest means initial speed is zero.", status: "Matched", source: "Teacher key · page 4" },
  { id: "q4", number: "27", prompt: "Frequency is the reciprocal of", options: "A wavelength · B period · C amplitude · D speed", answer: "", explain: "", status: "Uncertain", source: "Answer missing — AI may suggest" },
];

export const Route = createFileRoute("/admin/importer")({ component: Importer });

function Importer() {
  const [rows, setRows] = useState<Row[]>(seed);
  const [filter, setFilter] = useState("all");

  function approve(id: string) {
    setRows((current) => current.map((r) => (r.id === id ? { ...r, status: "Approved" } : r)));
    const ops = loadOps();
    ops.audit = [{ id: `a_${Date.now()}`, actor: "admin", action: "Approved question", target: id, at: new Date().toLocaleString("en-NG") }, ...ops.audit];
    saveOps(ops);
  }

  const shown = rows.filter((r) => filter === "all" || r.status === filter);

  return (
    <div>
      <h1 className="font-display text-4xl">Smart Quiz Importer</h1>
      <p className="mt-2 max-w-2xl text-sm text-muted">Correlate question pages with a separate answer key. Demo records only. Does not invent official past-question provenance.</p>
      <div className="mt-4 flex flex-wrap gap-2 text-sm">
        {["all", "Matched", "Uncertain", "Approved"].map((f) => (
          <button key={f} type="button" onClick={() => setFilter(f)} className={`min-h-10 rounded-full px-4 ${filter === f ? "bg-ink text-primary-fg" : "border border-line"}`}>{f}</button>
        ))}
      </div>
      <ul className="mt-4 space-y-3">
        {shown.map((row) => (
          <li key={row.id} className="rounded-2xl border border-line bg-surface p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="text-sm font-semibold">Q{row.number} · {row.status}</p>
              <span className="text-xs text-muted">{row.source}</span>
            </div>
            <p className="mt-2 font-medium">{row.prompt}</p>
            <p className="mt-1 text-sm text-muted">{row.options}</p>
            <p className="mt-2 text-sm">Answer: {row.answer || "Missing"} · Explanation: {row.explain || "None supplied"}</p>
            {row.status !== "Approved" && (
              <button type="button" onClick={() => approve(row.id)} className="mt-3 min-h-10 rounded-full bg-primary px-4 text-sm font-semibold text-primary-fg">Approve</button>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
