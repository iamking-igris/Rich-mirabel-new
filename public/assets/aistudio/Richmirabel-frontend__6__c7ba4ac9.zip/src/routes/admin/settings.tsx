import { createFileRoute } from "@tanstack/react-router";
import { useContent } from "@/lib/content";
import { useSession } from "@/lib/session";

export const Route = createFileRoute("/admin/settings")({ component: Settings });

function Settings() {
  const resetContent = useContent((s) => s.resetContent);
  const clearAttempts = useSession((s) => s.clearAllAttempts);
  const setDemo = useSession((s) => s.setDemoMode);
  const demo = useSession((s) => s.demoMode);

  return (
    <div>
      <h1 className="font-display text-4xl">Settings</h1>
      <p className="mt-2 text-sm text-muted">Admin controls for this device. Integrations below are not live.</p>
      <div className="mt-6 grid gap-3 sm:grid-cols-2">
        <button type="button" onClick={() => setDemo(!demo)} className="min-h-14 rounded-2xl border border-line bg-surface px-4 text-left text-sm font-semibold">
          Demo mode: {demo ? "On" : "Off"}
        </button>
        <button type="button" onClick={clearAttempts} className="min-h-14 rounded-2xl border border-line bg-surface px-4 text-left text-sm font-semibold">
          Clear all local attempts
        </button>
        <button type="button" onClick={resetContent} className="min-h-14 rounded-2xl border border-line bg-surface px-4 text-left text-sm font-semibold">
          Reset all content to seed
        </button>
      </div>
      <ul className="mt-6 divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
        <Row label="Platform name" value="Richmirabel" />
        <Row label="Trial" value="2 days (planned)" />
        <Row label="Term access" value="₦4,500 (planned, not charged here)" />
        <Row label="Admin login" value="Demo only · admin / admin" />
        <Row label="Firebase / auth" value="Not configured" />
        <Row label="Paystack" value="Not configured" />
        <Row label="Vision AI" value="Not configured" />
        <Row label="Publish rule" value="Admin can publish or hide any topic" />
      </ul>
    </div>
  );
}
function Row({ label, value }: { label: string; value: string }) {
  return <li className="flex items-center justify-between gap-4 px-4 py-3 text-sm"><span className="text-muted">{label}</span><span className="text-right font-medium">{value}</span></li>;
}
