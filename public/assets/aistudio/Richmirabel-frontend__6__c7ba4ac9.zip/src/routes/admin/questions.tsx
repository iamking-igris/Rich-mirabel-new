import { createFileRoute, Link } from "@tanstack/react-router";
import { publishedSubjects, useContent } from "@/lib/content";

export const Route = createFileRoute("/admin/questions")({ component: QuestionBank });

function QuestionBank() {
  const subjects = publishedSubjects(useContent((s) => s.subjects));
  const rows = subjects.flatMap((s) => s.topics.flatMap((t) => t.questions.map((q) => ({ subject: s.name, topic: t.title, topicId: t.id, id: q.id, prompt: q.prompt, status: q.answerKeyStatus ?? "shipped" }))));

  return (
    <div>
      <h1 className="font-display text-4xl">Question Bank</h1>
      <p className="mt-2 text-sm text-muted">{rows.length} questions currently loaded for students. Demo and shipped keys are labelled.</p>
      <div className="mt-4 overflow-x-auto rounded-2xl border border-line bg-surface">
        <table className="w-full min-w-[640px] text-left text-sm">
          <thead className="border-b border-line text-muted">
            <tr><th className="px-3 py-2">Subject</th><th className="px-3 py-2">Topic</th><th className="px-3 py-2">ID</th><th className="px-3 py-2">Prompt</th><th className="px-3 py-2">Key</th><th className="px-3 py-2"></th></tr>
          </thead>
          <tbody>
            {rows.slice(0, 40).map((r) => (
              <tr key={r.id} className="border-b border-line last:border-0">
                <td className="px-3 py-2">{r.subject}</td>
                <td className="px-3 py-2">{r.topic}</td>
                <td className="px-3 py-2">{r.id}</td>
                <td className="px-3 py-2">{r.prompt}</td>
                <td className="px-3 py-2">{r.status}</td>
                <td className="px-3 py-2"><Link to="/admin/topics/$id" params={{ id: r.topicId }} search={{ subject: "" }} className="font-semibold text-primary">Edit</Link></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p className="mt-3 text-sm text-muted">Showing first 40. <Link to="/admin/importer" className="text-primary">Import more</Link></p>
    </div>
  );
}
