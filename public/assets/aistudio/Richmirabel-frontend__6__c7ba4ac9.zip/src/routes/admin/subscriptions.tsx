import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";

export const Route = createFileRoute("/admin/subscriptions")({ component: Subscriptions });

type Plan = { id: string; name: string; price: number; days: number; active: boolean };

function Subscriptions() {
  const [plans, setPlans] = useState<Plan[]>([
    { id: "trial", name: "Free trial", price: 0, days: 2, active: true },
    { id: "term", name: "Term access", price: 4500, days: 120, active: true },
  ]);
  const [name, setName] = useState("");
  const [price, setPrice] = useState(4500);

  return (
    <div>
      <h1 className="font-display text-4xl">Subscriptions & Pricing</h1>
      <p className="mt-2 text-sm text-muted">Editable demo plans. Not charged and not enforced on real accounts.</p>
      <form
        className="mt-5 flex flex-wrap gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          if (!name.trim()) return;
          setPlans((current) => [...current, { id: `p_${Date.now()}`, name: name.trim(), price, days: 30, active: true }]);
          setName("");
        }}
      >
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Plan name" className="min-h-11 flex-1 rounded-xl border border-line bg-surface px-3" />
        <input type="number" value={price} onChange={(e) => setPrice(Number(e.target.value))} className="min-h-11 w-28 rounded-xl border border-line bg-surface px-3" />
        <button className="min-h-11 rounded-full bg-ink px-4 text-sm font-semibold text-primary-fg">Add plan</button>
      </form>
      <ul className="mt-6 divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
        {plans.map((plan) => (
          <li key={plan.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 text-sm">
            <span>{plan.name} · ₦{plan.price.toLocaleString("en-NG")} · {plan.days} days · {plan.active ? "Active" : "Off"}</span>
            <button type="button" onClick={() => setPlans((rows) => rows.map((row) => row.id === plan.id ? { ...row, active: !row.active } : row))} className="min-h-9 rounded-full border border-line px-3">
              {plan.active ? "Deactivate" : "Activate"}
            </button>
          </li>
        ))}
      </ul>
      <p className="mt-4 text-xs text-muted">Manual grants stay separate from paid subscriptions. See Payments for transactions.</p>
    </div>
  );
}
