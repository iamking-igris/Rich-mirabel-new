import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { seedPayments } from "@/data/seed-admin";
import { naira } from "@/lib/format";

export const Route = createFileRoute("/admin/payments")({ component: Payments });

function Payments() {
  const all = seedPayments();
  const [status, setStatus] = useState("All");
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<string | null>(null);
  const rows = useMemo(() => all.filter((p) => (status === "All" || p.status === status) && (p.name.toLowerCase().includes(q.toLowerCase()) || p.reference.toLowerCase().includes(q.toLowerCase()))), [all, status, q]);
  const success = all.filter((p) => p.status === "Successful");
  const failed = all.filter((p) => p.status === "Failed");
  const selected = all.find((p) => p.reference === open);

  return (
    <div>
      <h1 className="font-display text-4xl">Payments & Revenue</h1>
      <p className="mt-2 text-sm text-muted">Demo transactions. No payment provider is connected. Failed payments are not revenue.</p>
      <div className="mt-4 grid grid-cols-3 gap-3">
        <Stat label="Successful total" value={naira(success.reduce((s, p) => s + p.amount, 0))} />
        <Stat label="Successful count" value={String(success.length)} />
        <Stat label="Failed count" value={String(failed.length)} />
      </div>
      <div className="mt-4 flex flex-wrap gap-+2 gap-2">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search name or reference" className="min-h-11 flex-1 rounded-xl border border-line bg-surface px-3" />
        <select value={status} onChange={(e) => setStatus(e.target.value)} className="min-h-11 rounded-xl border border-line bg-surface px-3">
          <option>All</option>
          <option>Successful</option>
          <option>Failed</option>
        </select>
      </div>
      <ul className="mt-3 divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface">
        {rows.map((p) => (
          <li key={p.reference}>
            <button type="button" onClick={() => setOpen(p.reference)} className="flex w-full items-center justify-between px-4 py-3 text-left text-sm">
              <span>{p.name} · {p.reference} · {p.status}</span>
              <span>{naira(p.amount)}</span>
            </button>
          </li>
        ))}
        {rows.length === 0 && <li className="px-4 py-6 text-sm text-muted">No matching transactions.</li>}
      </ul>
      {selected && (
        <div className="fixed inset-0 z-30 flex items-end justify-center bg-ink/40 p-4 sm:items-center" role="dialog">
          <div className="w-full max-w-md rounded-3xl bg-surface p-6">
            <h2 className="font-display text-2xl">{selected.reference}</h2>
            <dl className="mt-3 space-y-2 text-sm">
              <div className="flex justify-between"><dt className="text-muted">Student</dt><dd>{selected.name}</dd></div>
              <div className="flex justify-between"><dt className="text-muted">Amount</dt><dd>{naira(selected.amount)}</dd></div>
              <div className="flex justify-between"><dt className="text-muted">Status</dt><dd>{selected.status}</dd></div>
              <div className="flex justify-between"><dt className="text-muted">Method</dt><dd>{selected.method}</dd></div>
            </dl>
            <button type="button" onClick={() => setOpen(null)} className="mt-5 min-h-11 w-full rounded-full bg-primary font-semibold text-primary-fg">Close</button>
          </div>
        </div>
      )}
    </div>
  );
}
function Stat({ label, value }: { label: string; value: string }) {
  return <div className="rounded-2xl border border-line bg-surface p-4"><p className="text-sm text-muted">{label}</p><p className="font-display text-2xl">{value}</p></div>;
}
