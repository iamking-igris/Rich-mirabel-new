const MAX_BYTES = 4 * 1024 * 1024;

const PROMPT = `You are digitising a teacher's handwritten or printed lesson into a clean digital note.
Return ONLY valid JSON with this shape:
{
  "objectives": ["what the student should be able to do"],
  "sections": [
    {
      "heading": "section title",
      "paragraphs": ["full paragraphs"],
      "formula": "optional equation",
      "points": ["optional list items"],
      "diagramCaption": "short caption if this section has a diagram",
      "diagramSvg": "optional simple SVG of the diagram, viewBox 0 0 640 240, no script, no external links"
    }
  ]
}
Rules:
- Put learning objectives in "objectives", not inside the body.
- Preserve the teacher's wording, values, units, formulas and order.
- Do not invent missing content. Mark unreadable text as [unclear].
- Keep formulas as plain text, e.g. v = fλ.
- If the page has a diagram, recreate it as a simple, clear, labelled SVG that is easier to read than the photo. Use #0d6b52 for the main line and #1a2420 for labels. If you cannot recreate it faithfully, leave diagramSvg empty and describe it in diagramCaption.
- If no objectives are written, return an empty array.`;

export async function extractNotes({ data }: { data: { name: string; type: string; base64: string } }) {
    const key = typeof process !== "undefined" && process.env?.GEMINI_API_KEY;
    if (!key) {
      return { ok: false as const, reason: "not-configured", message: "AI extraction is not configured. Set GEMINI_API_KEY or type the notes manually." };
    }
    const bytes = Math.ceil((data.base64.length * 3) / 4);
    if (bytes > MAX_BYTES) {
      return { ok: false as const, reason: "too-large", message: "That file is over 4 MB. Use a smaller page or type the notes." };
    }
    const allowed = ["image/png", "image/jpeg", "image/webp", "application/pdf"];
    if (!allowed.includes(data.type)) {
      return { ok: false as const, reason: "unsupported", message: "Use PNG, JPG, WebP, or PDF." };
    }
    const body = {
      contents: [{
        parts: [
          { text: PROMPT },
          { inline_data: { mime_type: data.type, data: data.base64 } },
        ],
      }],
      generationConfig: { responseMimeType: "application/json" },
    };
    try {
      const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${key}`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        return { ok: false as const, reason: "provider", message: `Extraction failed (${res.status}). The source and existing notes were kept. Try again or type the notes.` };
      }
      const json = await res.json() as { candidates?: { content?: { parts?: { text?: string }[] } }[] };
      const raw = json.candidates?.[0]?.content?.parts?.map((p) => p.text ?? "").join("\n").trim();
      if (!raw) return { ok: false as const, reason: "empty", message: "The service returned no text. The source was kept. Try again or type the notes." };
      return { ok: true as const, text: raw };
    } catch {
      return { ok: false as const, reason: "network", message: "Could not reach the extraction service. The source and existing notes were kept." };
    }
}

