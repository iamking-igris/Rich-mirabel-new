import { extractNotes } from "@/lib/extract.server";
import type { NoteBlock } from "@/data/catalog";

export type Extracted = { objectives: string[]; notes: NoteBlock[] };
export type ExtractResult =
  | { ok: true; extracted: Extracted }
  | { ok: false; reason: string; message: string };

function asNotes(raw: string): Extracted {
  try {
    const parsed = JSON.parse(raw) as { objectives?: unknown; sections?: unknown };
    const objectives = Array.isArray(parsed.objectives) ? parsed.objectives.map(String).filter(Boolean) : [];
    const sections = Array.isArray(parsed.sections) ? parsed.sections : [];
    const notes: NoteBlock[] = sections.map((section) => {
      const s = section as { heading?: unknown; paragraphs?: unknown; formula?: unknown; points?: unknown; diagramCaption?: unknown; diagramSvg?: unknown };
      return {
        heading: typeof s.heading === "string" ? s.heading : "Notes",
        paragraphs: Array.isArray(s.paragraphs) ? s.paragraphs.map(String).filter(Boolean) : [],
        formula: typeof s.formula === "string" && s.formula.trim() ? s.formula : undefined,
        points: Array.isArray(s.points) ? s.points.map(String).filter(Boolean) : undefined,
        diagramCaption: typeof s.diagramCaption === "string" && s.diagramCaption.trim() ? s.diagramCaption : undefined,
        diagramSvg: typeof s.diagramSvg === "string" && s.diagramSvg.includes("<svg") ? s.diagramSvg : undefined,
      };
    }).filter((b) => b.heading || b.paragraphs.length);
    return { objectives, notes: notes.length ? notes : [{ heading: "Extracted notes", paragraphs: [raw] }] };
  } catch {
    return { objectives: [], notes: [{ heading: "Extracted notes", paragraphs: raw.split(/\n+/).filter(Boolean) }] };
  }
}

export async function extractFromFile(file: File): Promise<ExtractResult> {
  const base64 = await file.arrayBuffer().then((buf) => btoa(String.fromCharCode(...new Uint8Array(buf))));
  const result = await extractNotes({ data: { name: file.name, type: file.type, base64 } });
  if (!result.ok) return result;
  return { ok: true, extracted: asNotes(result.text) };
}
